
MDP-lab - v2 2020-09-29 4:14pm
==============================

This dataset was exported via roboflow.ai on September 29, 2020 at 8:15 AM GMT

It includes 250 images.
Signs are annotated in YOLO v3 Darknet format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


